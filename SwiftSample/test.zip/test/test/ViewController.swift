//
//  ViewController.swift
//  test
//
//  Created by 馮徳江 on 2017/01/07.
//  Copyright © 2017年 fdj. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    let zero:Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet weak var inputField: UITextField!
    @IBOutlet weak var inputField2: UITextField!
    @IBOutlet weak var inputField3: UITextField!
    
    @IBOutlet weak var resultField2: UILabel!

    @IBAction func zero(_ sender: Any) {
        inputField.text=String(Double(zero));
        inputField2.text=String(Double(zero));
        inputField3.text=String(Double(zero));
        resultField2.text=""
    }

    @IBAction func calcButton(_ sender: AnyObject) {
        var result:Double=0
        
        if Double(inputField.text!) == nil{
            inputField.text=String(Double(result));
        }
        if Double(inputField2.text!) == nil{
            inputField2.text=String(Double(result));
        }
        if Double(inputField3.text!) == nil{
            inputField3.text=String(Double(result));
        }
        result=Double(inputField.text!)!+Double(inputField2.text!)!-Double(inputField3.text!)!

        resultField2.text=String(Double(result))
        
    }
}

